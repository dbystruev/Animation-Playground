import PlaygroundSupport
import UIKit

let liveViewFrame = CGRect(x: 0, y: 0, width: 500, height: 500)
let liveView = UIView(frame: liveViewFrame)
liveView.backgroundColor = .white

let smallFrame = CGRect(x: 0, y: 0, width: 100, height: 100)
let square = UIView(frame: smallFrame)
square.backgroundColor = .purple

liveView.addSubview(square)

let button = UIButton(frame: CGRect(x: 400, y: 0, width: 100, height: 100))
button.backgroundColor = .red
button.setTitleColor(.yellow, for: [])
button.setTitle("OK", for: [])
button.titleLabel?.font = .systemFont(ofSize: 50)
liveView.addSubview(button)

class Animate {
    var firstAnimationFlag = true
    
    var animation: UIViewPropertyAnimator!
    
    let firstAnimation = UIViewPropertyAnimator(duration: 5, curve: .easeInOut) {
        button.backgroundColor = .red
        button.frame.origin = CGPoint(x: 0, y: 400)
    }
    
    let secondAnimation = UIViewPropertyAnimator(duration: 5, curve: .easeInOut) {
        button.backgroundColor = .black
        button.frame.origin = CGPoint(x: 400, y: 0)
    }
    
    init() {
        firstAnimation.addCompletion {_ in
            print("First Animation Finished")
        }
        
        secondAnimation.addCompletion {_ in
            print("Second Animation Finished")
        }
    }
    
    
    @objc func doAnimation() {
        print(#function, firstAnimationFlag)
        
        if firstAnimationFlag {
            animation = firstAnimation
            animation.startAnimation()
        } else {
            animation = secondAnimation
            animation.startAnimation()
        }

        firstAnimationFlag.toggle()
    }
}

let animate = Animate()

button.addTarget(animate, action: #selector(Animate.doAnimation), for: .touchUpInside)

UIView.animate(withDuration: 2, delay: 2, options: [.autoreverse, .repeat], animations: {
    
    let scaleTransform = CGAffineTransform(scaleX: 2, y: 2)
    let rotateTransform = CGAffineTransform(rotationAngle: .pi)
    let translateTransform = CGAffineTransform(translationX: 200, y: 200)
    let comboTranform = scaleTransform.concatenating(rotateTransform).concatenating(translateTransform)
    
    square.transform = comboTranform
    
    //    CGAffineTransform.identity
})

PlaygroundPage.current.liveView = liveView
